<section class="hero-banner magic-ball pb-5">
    <div class="container">

    <div class="row align-items-center text-center text-md-left pb-5">
        <div class="col-md-6 col-lg-5 mb-5 mb-md-0">
        <h1>404 Not Found</h1>
        <p>
        Halaman yang anda cari tidak ditemukan
        </p>  
        </div>
        <div class="col-md-6 col-lg-7 col-xl-6 offset-xl-1">
        <img class="img-fluid" src="<?php echo base_url();?>_assets/safario/img/home/hero-img-404.png" alt="">
        </div>
    </div>
    </div>
</section>